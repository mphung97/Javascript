import { connect } from 'react-redux'
import { addTodo, completeAllTodo, clearCompleted, setVisibilityFilter } from '../actions'
import { SHOW_ALL, SHOW_ACTIVE, SHOW_COMPLETED } from '../constant/FilterTypes'
import Header from '../components/Header';


const mapDispatchToProps = dispatch => ({
    addTodo: text => dispatch(addTodo(text)),
    completeAllTodo: () => dispatch(completeAllTodo()),
    clearCompleted: () => dispatch(clearCompleted()),
    showAll: () => dispatch(setVisibilityFilter(SHOW_ALL)),
    showActive: () => dispatch(setVisibilityFilter(SHOW_ACTIVE)),
    showComplete: () => dispatch(setVisibilityFilter(SHOW_COMPLETED)),
})

export default connect(null, mapDispatchToProps)(Header)