import TodoList from '../components/TodoList'
import { connect } from 'react-redux'
import { completeTodo, deleteTodo, editTodo, fetchTodos } from '../actions'
import { SHOW_ALL, SHOW_ACTIVE, SHOW_COMPLETED } from '../constant/FilterTypes'

const getVisibleTodos = (todos, filter) => {
    switch (filter) {
        case SHOW_ALL:
            return todos.data
        case SHOW_ACTIVE:
            return todos.data.filter(todo => todo.completed === false)
        case SHOW_COMPLETED:
            return todos.data.filter(todo => todo.completed === true)
        default:
            throw new Error('Unknown filter: ' + filter)
    }
}

const mapStateToProps = state => ({
    todos: getVisibleTodos(state.todos, state.filter)
})

const mapDispatchToProps = dispatch => ({
    completeTodo: id => dispatch(completeTodo(id)),
    deleteTodo: id => dispatch(deleteTodo(id)),
    editTodo: (id, title) => dispatch(editTodo(id, title)),
    fetchTodos: () => dispatch(fetchTodos())
})

export default connect(mapStateToProps, mapDispatchToProps)(TodoList)