import {
    ADD_TODO,
    DELETE_TODO,
    EDIT_TODO,
    COMPLETE_TODO,
    COMPLETE_ALL_TODOS,
    CLEAR_COMPLETED,
    FETCH_TODOS,
    FETCH_SUCCESS,
    FETCH_ERROR
} from '../constant/ActionTypes'

const todos = (
    state = {
        fetching: false,
        fetched: false,
        data: [],
        error: null
    },
    action
) => {
    switch (action.type) {
        case FETCH_TODOS:
            return {
                ...state,
                fetching: true
            }
        case FETCH_SUCCESS:
            return {
                ...state,
                fetching: false,
                fetched: true,
                data: action.todos
            }
        case FETCH_ERROR:
            return {
                ...state,
                fetching: false,
                fetched: true,
                error: action.error
            }

        case ADD_TODO:
            return {
                ...state,
                data: [
                    ...state.data,
                    {
                        id: action.id,
                        title: action.title,
                        completed: false
                    }
                ]
            }
        case DELETE_TODO:
            return {
                ...state,
                data: state.data.filter(todo =>
                    todo.id !== action.id
                )
            }
        case EDIT_TODO:
            return {
                ...state,
                data: state.data.map(todo =>
                    todo.id === action.id ?
                        { ...todo, title: action.title } :
                        todo
                )
            }
        case COMPLETE_TODO:
            return {
                ...state,
                data: state.data.map(todo =>
                    (todo.id === action.id)
                        ? {
                            ...todo,
                            completed: !todo.completed
                        }
                        : todo
                )
            }
        case COMPLETE_ALL_TODOS:
            return {
                ...state,
                data: state.data.map(todo =>
                    ({
                        ...todo,
                        completed: true
                    })
                )
            }
        case CLEAR_COMPLETED:
            return {
                ...state,
                data: state.data.filter(todo =>
                    todo.completed === false
                )
            }
        default:
            return state;
    }
}

export default todos