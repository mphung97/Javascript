import React, { Component } from 'react'
import '../css/App.css'

class TextInput extends Component {

    handleSubmit = e => {
        const text = e.target.value.trim()
        if (e.which === 13) {
            this.props.onSave(text)
            e.target.value = ''
        }
    }

    render() {
        const { placeholder } = this.props

        return (
            <div className='input'>
                <input
                    autoFocus={true}
                    onKeyDown={this.handleSubmit}
                    placeholder={placeholder}
                    className='form-control-borderless'
                />
            </div>
        );
    }
}

export default TextInput;