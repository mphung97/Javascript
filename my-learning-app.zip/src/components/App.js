import React, { Component } from 'react'
import TodoList from '../containers/TodoList'
import Headers from '../containers/Header';

class App extends Component {
  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <Headers />
        <TodoList />
      </div>
    );
  }
}

export default App
