import React, { Component } from 'react'
import Todo from './Todo'

class TodoList extends Component {
    componentDidMount() {
        const { fetchTodos } = this.props
        fetchTodos()
    }

    render() {
        const { todos, completeTodo, deleteTodo, editTodo } = this.props
        return (
            todos.map(todo =>
                <Todo
                    key={todo.id}
                    {...todo}
                    onComplete={() => {
                        completeTodo(todo.id)
                    }}
                    onDelete={() => {
                        deleteTodo(todo.id)
                    }}
                    onEdit={(text) => {
                        editTodo(todo.id, text)
                    }}
                />
            )
        );
    }
}

export default TodoList;