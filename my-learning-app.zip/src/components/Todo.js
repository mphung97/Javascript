import React, { Component } from 'react'
import TextInput from './TextInput'
import '../css/App.css'

class Todo extends Component {

    state = {
        editing: false
    }

    handleEdit = () => {
        if (!this.state.editing) {
            this.setState({ editing: true })
        }
        else {
            this.setState({ editing: false })
        }
    }

    render() {
        const { editing } = this.state
        const { title, completed, onComplete, onDelete, onEdit } = this.props

        let element
        if (editing) {
            element = (
                <React.Fragment>
                    <TextInput
                        placeholder='Edit todo'
                        onSave={(text) => onEdit(text)}
                        onKeyDown={e => this.handleEdit} />
                    <button className='btn red'
                        onClick={this.handleEdit}>
                        Cancel
                    </button>
                </React.Fragment>
            )
        } else {
            element = (
                <React.Fragment>
                    <span style={{
                        textDecoration: completed ? 'line-through' : 'none'
                    }} onClick={onComplete}>
                        {title}
                    </span>
                    <button onClick={onDelete} className='btn red'>Delete</button>
                    <button onClick={this.handleEdit} className='btn green'>Edit</button>
                </React.Fragment>
            )
        }

        return (
            <div>
                {element}
            </div>
        );
    }
}

export default Todo;