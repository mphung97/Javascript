import React, { Component } from 'react'
import TextInput from './TextInput'
import '../css/App.css'

class Header extends Component {
    render() {
        const { addTodo, completeAllTodo, clearCompleted, showAll, showComplete, showActive } = this.props
        return (
            <div className='action-bar'>
                <button onClick={() => showAll()} className='btn green'>All</button>
                <button onClick={() => showActive()} className='btn green'>Active</button>
                <button onClick={() => showComplete()} className='btn green'>Complete</button><br />
                <button onClick={() => completeAllTodo()} className='btn red'>Complete All</button>
                <button onClick={() => clearCompleted()} className='btn red'>Clear Complete</button>
                <TextInput
                    placeholder='Add todo'
                    onSave={(text) => {
                        if (text.length !== 0) {
                            addTodo(text)
                        }
                    }} />
            </div>
        );
    }
}

export default Header;