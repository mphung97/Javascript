import fetch from 'cross-fetch'
import {
    ADD_TODO,
    EDIT_TODO,
    DELETE_TODO,
    COMPLETE_TODO,
    CLEAR_COMPLETED,
    COMPLETE_ALL_TODOS,
    SET_VISIBILITY_FILTER,
    FETCH_TODOS
} from '../constant/ActionTypes'

let nextId = 0

export const addTodo = title => ({ type: ADD_TODO, id: nextId++, title })
export const deleteTodo = id => ({ type: DELETE_TODO, id })
export const clearCompleted = () => ({ type: CLEAR_COMPLETED })
export const completeTodo = id => ({ type: COMPLETE_TODO, id })
export const completeAllTodo = () => ({ type: COMPLETE_ALL_TODOS })
export const editTodo = (id, title) => ({ type: EDIT_TODO, id, title })
export const setVisibilityFilter = filter => ({ type: SET_VISIBILITY_FILTER, filter: filter })

/* Async Action Todo */
export const fetchTodos = () => {
    return dispatch => {
        dispatch({ type: FETCH_TODOS })
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(response => response.json())
            .then(json => dispatch({ type: 'FETCH_SUCCESS', todos: json }))
            .catch(err => dispatch({ type: 'FETCH_ERROR', error: err }))
    }
}